<?php
/**
 * Shortcode Showcase Admin Page
 *
 * Displays the admin page for shortcode showcase with documentation
 * and examples of available shortcodes
 *
 * @package Shortcodeglut
 * @subpackage ShortcodeShowcase
 */

namespace Shortcodeglut\shortcodeShowcase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AdminPage {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueueAdminAssets' ) );
	}

	/**
	 * Enqueue assets for admin page
	 */
	public function enqueueAdminAssets( $hook ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Safe admin page parameter check for script loading
		if ( isset( $_GET['page'] ) && 'shortcodeglut' === sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) {
			// Enqueue styles
			wp_enqueue_style(
				'shortcodeglut-shortcode-showcase',
				SHORTCODEGLUT_URL . 'src/shortcodeShowcase/shortcode-showcase.css',
				array(),
				SHORTCODEGLUT_VERSION
			);

			// Enqueue scripts
			wp_enqueue_script(
				'shortcodeglut-shortcode-showcase',
				SHORTCODEGLUT_URL . 'src/shortcodeShowcase/shortcode-showcase.js',
				array( 'jquery' ),
				SHORTCODEGLUT_VERSION,
				true
			);

			// Enqueue admin JavaScript (contains modal and copy functionality)
			wp_enqueue_script(
				'shortcodeglut-shortcode-showcase-admin',
				SHORTCODEGLUT_URL . 'src/shortcodeShowcase/shortcode-showcase-admin.js',
				array( 'jquery', 'shortcodeglut-shortcode-showcase' ),
				SHORTCODEGLUT_VERSION,
				true
			);

			// Localize script with translation strings
			wp_localize_script( 'shortcodeglut-shortcode-showcase-admin', 'shortcodeglutShowcase', array(
				'i18n' => array(
					'description' => esc_html__( 'Description', 'shortcodeglut' ),
					'shortcodeSyntax' => esc_html__( 'Shortcode Syntax', 'shortcodeglut' ),
					'howToUse' => esc_html__( 'How to Use', 'shortcodeglut' ),
					'copyShortcode' => esc_html__( 'Copy the shortcode using the button above or the copy button on the card', 'shortcodeglut' ),
					'pasteShortcode' => esc_html__( 'Paste it into any WordPress page, post, or widget', 'shortcodeglut' ),
					'customizeParams' => esc_html__( 'Customize parameters as needed', 'shortcodeglut' ),
					'createTemplate' => esc_html__( 'For custom styling, create a WooTemplate in the Woo Templates section', 'shortcodeglut' ),
					'availableParams' => esc_html__( 'Available Parameters', 'shortcodeglut' ),
					'parameter' => esc_html__( 'Parameter', 'shortcodeglut' ),
					'searchPlaceholder' => esc_attr__( 'Search...', 'shortcodeglut' ),
					'orderByDate' => esc_html__( 'Order By: Date', 'shortcodeglut' ),
					'orderByTitle' => esc_html__( 'Order By: Title', 'shortcodeglut' ),
					'orderByPrice' => esc_html__( 'Order By: Price', 'shortcodeglut' ),
					'descending' => esc_html__( 'Descending', 'shortcodeglut' ),
					'ascending' => esc_html__( 'Ascending', 'shortcodeglut' ),
					'apply' => esc_html__( 'Apply', 'shortcodeglut' ),
					'title' => esc_html__( 'Title', 'shortcodeglut' ),
					'price' => esc_html__( 'Price', 'shortcodeglut' ),
					'stock' => esc_html__( 'Stock', 'shortcodeglut' ),
					'action' => esc_html__( 'Action', 'shortcodeglut' ),
					'inStock' => esc_html__( 'In Stock', 'shortcodeglut' ),
					'outOfStock' => esc_html__( 'Out of Stock', 'shortcodeglut' ),
					'addToCart' => esc_html__( 'Add to Cart', 'shortcodeglut' ),
					'readMore' => esc_html__( 'Read more', 'shortcodeglut' ),
					'showingProducts' => esc_html__( 'Showing 3 of 25 products', 'shortcodeglut' ),
					'wooCategoryPreview' => esc_html__( 'WooCommerce Category Products Preview', 'shortcodeglut' ),
					'productTablePreview' => esc_html__( 'Product Table Preview', 'shortcodeglut' ),
					'saleProductsPreview' => esc_html__( 'Products On Sale Preview', 'shortcodeglut' ),
					'wirelessHeadphones' => esc_html__( 'Wireless Headphones', 'shortcodeglut' ),
					'smartWatchPro' => esc_html__( 'Smart Watch Pro', 'shortcodeglut' ),
					'bluetoothSpeaker' => esc_html__( 'Bluetooth Speaker', 'shortcodeglut' ),
					'laptopStand' => esc_html__( 'Laptop Stand', 'shortcodeglut' ),
					'browseElectronicProducts' => esc_html__( 'Browse our electronic products', 'shortcodeglut' ),
					'electronics' => esc_html__( 'Electronics', 'shortcodeglut' ),
					'copiedToClipboard' => esc_html__( 'Shortcode copied to clipboard!', 'shortcodeglut' ),
					'failedToCopy' => esc_html__( 'Failed to copy shortcode', 'shortcodeglut' ),
					// Additional strings for preview
					'electronics' => esc_html__( 'Electronics', 'shortcodeglut' ),
				)
			) );
		}
	}

	/**
	 * Render the shortcode showcase admin page content
	 */
	public function renderShortcodeShowcaseContent() {
		$woo_active = class_exists( 'WooCommerce' );
		?>
		<div class="wrap shopglut-admin-contents">
			<h1 style="text-align: center; font-weight: 600; font-size: 32px; margin: 30px 0;">
				Shortcode Showcase
			</h1>
			<p class="subheading" style="text-align: center; margin-bottom: 30px; margin-top: 8px; color: #6b7280;">
				Display WooCommerce content with powerful shortcodes
			</p>

			<?php if ( ! $woo_active ) : ?>
				<div class="notice notice-warning inline" style="max-width: 800px; margin: 0 auto 30px;">
					<p><?php esc_html_e( 'WooCommerce is not active. Some shortcodes may not work until WooCommerce is activated.', 'shortcodeglut' ); ?></p>
				</div>
			<?php endif; ?>

			<div class="shopg-tab-container">
				<ul class="shopg-tabs">
					<li class="shopg-tab active" data-tab="tab-all" style="font-size: 16px; font-weight: 600;">All Shortcodes</li>
				</ul>

				<div class="shopg-tab-content active" id="tab-all">
					<div class="image-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px;">

						<?php
						// WooCommerce Category Shortcode
						$this->render_shortcode_card(
							'shopglut_woo_category',
							'WooCommerce Category Products',
							'Query and display products from one or more WooCommerce categories with customizable layout, filtering, and pagination.',
							array(
								'basic' => '[shopglut_woo_category id="your-category-slug"]',
								'advanced' => '[shopglut_woo_category id="electronics,accessories" title="1" desc="1" items_per_page="12" cols="3" toolbar="1"]',
							),
							array(
								'id' => 'Category slug(s) - comma-separated for multiple (required)',
								'cat_field' => 'Field type: slug or id (default: slug)',
								'operator' => 'Query operator: IN, NOT IN, AND (default: IN)',
								'title' => 'Custom title or "1" for category name',
								'desc' => 'Custom description or "1" for category description',
								'icon' => 'Custom icon URL',
								'icon_width' => 'Icon width in pixels (default: 64)',
								'items_per_page' => 'Number of products per page (default: 10)',
								'orderby' => 'Order by: date, title, modified, price, total_sales, menu_order (default: date)',
								'order' => 'Order direction: ASC or DESC (default: DESC)',
								'template' => 'WooTemplate ID for custom product display',
								'toolbar' => 'Show toolbar: 1, 0, or "compact" (default: 1)',
								'tbgrid' => 'Toolbar grid allocation (default: 6,2,2,2)',
								'paging' => 'Show pagination: 1 or 0 (default: 1)',
								'cols' => 'Number of columns on desktop (default: 1)',
								'colspad' => 'Number of columns on tablet (default: 1)',
								'colsphone' => 'Number of columns on mobile (default: 1)',
								'async' => 'Load pagination asynchronously: 1 or 0 (default: 0)',
							),
							'woo-category'
						);

						// Product Table Shortcode
						$this->render_shortcode_card(
							'shopglut_product_table',
							'Product Table',
							'Display products in an interactive data table with custom search, filters, column sorting, and pagination. Features real-time filtering, category/tag/stock dropdowns, and AJAX add-to-cart with View Cart button.',
							array(
								'basic' => '[shopglut_product_table]',
								'advanced' => '[shopglut_product_table design="modern" title="My Products" items_per_page="25" show_category_filter="1" show_stock_filter="1"]',
							),
							array(
								'cols' => 'Column definition (| separated, , for multiple fields) - default: title|price|stock|categories|date|add_to_cart',
								'colheads' => 'Column headers (| separated) - default: Product|Price|Stock|Categories|Date|Action',
								'design' => 'Design style: classic or modern (default: classic)',
								'title' => 'Table title (modern design)',
								'description' => 'Table description (modern design)',
								'show_items_per_page' => 'Show items per page dropdown: 1 or 0 (default: 1)',
								'items_per_page' => 'Items per page: 10, 25, 50, or 100 (default: 10)',
								'show_search' => 'Show search field: 1 or 0 (default: 1)',
								'show_category_filter' => 'Show category dropdown: 1 or 0 (default: 1)',
								'show_tag_filter' => 'Show tag dropdown: 1 or 0 (default: 0)',
								'show_stock_filter' => 'Show stock status dropdown: 1 or 0 (default: 0)',
								'orderby' => 'Order field: date, title, price, modified (default: date)',
								'order' => 'Order direction: ASC or DESC (default: DESC)',
								'categories' => 'Filter by category slugs (comma-separated)',
								'exclude' => 'Exclude product IDs (comma-separated)', // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- Documentation string only
								'include' => 'Include only product IDs (comma-separated)',
								'thumb' => 'Show thumbnail: 1 or 0 (default: 0)',
								'thumb_width' => 'Thumbnail width in pixels (default: 48)',
								'template' => 'WooTemplate ID for custom product display',
								'login' => 'Require login to view: 1 or 0 (default: 0)',
								'sorting' => 'Enable column sorting: 1 or 0 (default: 1)',
								'responsive' => 'Enable responsive table: 1 or 0 (default: 1)',
							),
							'product-table'
						);

						// Sale Products Shortcode
						$this->render_shortcode_card(
							'shopglut_sale_products',
							'Products On Sale',
							'Display products currently on sale with discount badges. Perfect for showcasing promotions, special offers, and clearance items.',
							array(
								'basic' => '[shopglut_sale_products]',
								'advanced' => '[shopglut_sale_products limit="12" columns="4" orderby="price" show_rating="1"]',
							),
							array(
								'limit' => 'Number of products to display (default: 12)',
								'columns' => 'Number of columns (1-6, default: 4)',
								'orderby' => 'Order by: date, title, price, popularity, rating (default: date)',
								'order' => 'Order direction: ASC or DESC (default: DESC)',
								'category' => 'Filter by category slug',
								// phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- Documentation string only, properly sanitized in implementation
								'exclude' => 'Exclude product IDs (comma-separated)',
								'template' => 'WooTemplate ID for custom product display',
								'paging' => 'Enable pagination: 1 or 0 (default: 0)',
								'items_per_page' => 'Items per page when paging enabled (default: 12)',
								'show_image' => 'Show product image: 1 or 0 (default: 1)',
								'show_title' => 'Show product title: 1 or 0 (default: 1)',
								'show_price' => 'Show product price: 1 or 0 (default: 1)',
								'show_button' => 'Show add to cart button: 1 or 0 (default: 1)',
								'show_rating' => 'Show product rating: 1 or 0 (default: 0)',
								'show_badge' => 'Show sale badge: 1 or 0 (default: 1)',
							),
							'sale-products'
						);
						?>

					</div>
				</div>
			</div>
		</div>

		<!-- Details Modal -->
		<div id="shopglut-details-modal" style="display: none;">
			<div class="shopglut-modal-overlay" onclick="closeDetailsModal()"></div>
			<div class="shopglut-modal-container">
				<div class="shopglut-modal-header">
					<h3 id="shopglut-details-title"></h3>
					<button type="button" class="shopglut-modal-close" onclick="closeDetailsModal()">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="shopglut-modal-body" id="shopglut-details-body"></div>
			</div>
		</div>

		<!-- Preview Modal -->
		<div id="shopglut-preview-modal" style="display: none;">
			<div class="shopglut-modal-overlay" onclick="closePreviewModal()"></div>
			<div class="shopglut-modal-container shopglut-preview-modal-container">
				<div class="shopglut-modal-header">
					<h3 id="shopglut-preview-title"></h3>
					<button type="button" class="shopglut-modal-close" onclick="closePreviewModal()">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="shopglut-modal-body" id="shopglut-preview-body"></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render a shortcode card
	 *
	 * @param string $shortcode The shortcode tag
	 * @param string $title Display title
	 * @param string $description Shortcode description
	 * @param array $examples Example shortcodes (basic, advanced)
	 * @param array $params Parameters documentation
	 * @param string $preview_type Preview type for demo
	 */
	private function render_shortcode_card( $shortcode, $title, $description, $examples, $params, $preview_type ) {
		// Store shortcode data for JavaScript
		$data = array(
			'shortcode' => $shortcode,
			'title' => $title,
			'description' => $description,
			'examples' => $examples,
			'params' => $params,
		);
		$data_json = wp_json_encode( $data );
		?>
		<div class="shortcode-card" data-shortcode-data='<?php echo esc_attr( $data_json ); ?>'>
			<div class="shortcode-card-header">
				<h3><?php echo esc_html( $title ); ?></h3>
				<p><?php echo esc_html( $description ); ?></p>
			</div>

			<div class="shortcode-display">
				<div class="shortcode-code-wrapper">
					<code><?php echo esc_html( $examples['basic'] ); ?></code>
					<button type="button" class="copy-btn" onclick="copyShortcode('<?php echo esc_js( $examples['basic'] ); ?>', this)" title="<?php esc_attr_e( 'Copy shortcode', 'shortcodeglut' ); ?>">
						<span class="dashicons dashicons-admin-page"></span>
					</button>
				</div>
			</div>

			<div class="shortcode-actions">
				<button type="button" class="shortcode-action-btn details-btn">
					<span class="dashicons dashicons-info-outline"></span>
					<?php esc_html_e( 'Details', 'shortcodeglut' ); ?>
				</button>
				<button type="button" class="shortcode-action-btn preview-btn" onclick="showPreviewModal('<?php echo esc_js( $preview_type ); ?>')">
					<span class="dashicons dashicons-welcome-view-site"></span>
					<?php esc_html_e( 'Preview', 'shortcodeglut' ); ?>
				</button>
			</div>
		</div>
		<?php
	}
}
